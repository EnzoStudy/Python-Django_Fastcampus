from django.urls import path

from .views import OrderCreate, OrderList

#order 관련 url 관리

urlpatterns = [
    path('', OrderList.as_view()),
    path('create/', OrderCreate.as_view()),

]
