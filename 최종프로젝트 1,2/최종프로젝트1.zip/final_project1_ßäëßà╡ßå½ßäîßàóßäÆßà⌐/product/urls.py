
from django.urls import path

from .views import (
    ProductList, ProductCreate, ProductDetail,
)

#product 관련 url 관리

urlpatterns = [
    path('', ProductList.as_view()),
    path('<int:pk>/', ProductDetail.as_view()),
    path('create/', ProductCreate.as_view()),
]
