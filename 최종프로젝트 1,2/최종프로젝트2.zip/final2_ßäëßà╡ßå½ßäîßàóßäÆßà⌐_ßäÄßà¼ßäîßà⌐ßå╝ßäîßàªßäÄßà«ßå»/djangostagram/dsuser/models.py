from django.db import models
from django.db.models.fields import EmailField
# from django.db.models.query_utils import RegisterLookupMixin


class Dsuser(models.Model):
    #아이디, 이메일, 비밀번호, 가입일자 데이터 설정
    user_id = models.CharField(max_length=64, verbose_name='아이디', unique=True) 
    email = models.EmailField(verbose_name='이메일')
    password = models.CharField(max_length=64, verbose_name='비밀번호')
    register_date = models.DateTimeField(auto_now_add=True, verbose_name='등록날짜')
    
    def __str__(self):
        return self.user_id

    class Meta:
        #테이블 별명 설정
        db_table = 'djangostagram_user'
        #보여주는 별명 설정
        verbose_name = '사용자'
        #복수형태로 보여주는거 없애기
        verbose_name_plural = '사용자'





