from django.contrib import admin
from .models import Dsuser

#관리자 화면 관리
class DsuserAdmin(admin.ModelAdmin):
    list_display = ('user_id', 'email', 'password', 'register_date')

admin.site.register(Dsuser, DsuserAdmin)