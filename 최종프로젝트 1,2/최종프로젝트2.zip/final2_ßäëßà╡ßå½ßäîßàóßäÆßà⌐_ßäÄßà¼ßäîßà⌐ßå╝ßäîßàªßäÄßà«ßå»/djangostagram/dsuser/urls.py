#앱 > urls.py에 작성되는 부분
from django.urls import path , include
from . import views

app_name = 'user'

urlpatterns = [
  	#view 파트쪽에 register 함수와 연결
  	#연결하기 위해 from . import view 작성

	#로그아웃 연결
    path('logout/', views.logout),

    #회원가입을 위한 url
    path('register/', views.RegisterView.as_view()),

    #로그인
    path('login/', views.LoginView.as_view()),
]
