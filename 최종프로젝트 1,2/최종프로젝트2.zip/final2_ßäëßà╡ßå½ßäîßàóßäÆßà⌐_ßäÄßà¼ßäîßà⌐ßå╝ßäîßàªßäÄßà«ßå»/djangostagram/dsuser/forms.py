from django import forms
from .models import Dsuser
from django.contrib.auth.hashers import check_password, make_password

class RegisterForm(forms.Form):
# 회원가입을 위한 폼
    user_id = forms.CharField(
        error_messages={'required' : '아이디를 입력하시오.'},
        max_length=64, label='아이디'
    )
    email = forms.EmailField(
        error_messages={'required' : '이메일을 입력하시오.'},
        max_length=64, label='이메일'
    )
    password = forms.CharField(
        error_messages={'required' : '비밀번호를 입력하시오.'},
        widget=forms.PasswordInput, label='비밀번호'
    )
    re_password = forms.CharField(
        error_messages={'required' : '비밀번호를 입력하시오.'},
        widget=forms.PasswordInput, label='비밀번호 확인'
    )

    #오류 발생시 데이터 제거 후 오류 전달
    def clean(self):
        cleaned_data = super().clean()

        user_id = cleaned_data.get('user_id')
        email = cleaned_data.get('email')
        password = cleaned_data.get('password')
        re_password = cleaned_data.get('re_password')

        #데이터 입력 안되었으면 오류 출력
        if not (user_id or email or password or re_password):
            self.add_error('user_id', '모든값 입력해주세요.')

        #비밀번호가 다르면 오류 출력
        if password ==re_password:
            dsuser = Dsuser(
                user_id = user_id,
                email = email,
                password = make_password(password)
            )
            #비밀번호도 같고, 데이터도 다 있으면 저장
            if (user_id and email and password and re_password):
                dsuser.save()
        elif password != re_password:
            self.add_error('password', '비밀번호가 다릅니다.')


class LoginForm(forms.Form):
    #로그인폼 지정하는 클래스
    #User_id 폼 지정
    user_id = forms.CharField(
        error_messages={'required' : '아이디를 입력하시오.'},
        max_length=64, label='아이디'
    )
    # password 폼 지정
    password = forms.CharField(
        error_messages={'required' : '비밀번호를 입력하시오.'},
        widget=forms.PasswordInput, label='비밀번호'
    )

    #오류 발생시 데이터 제거 후 오류 전달
    def clean(self):
        cleaned_data = super().clean()
        user_id = cleaned_data.get('user_id')
        password = cleaned_data.get('password')

        if user_id and password:
            try:
                dsuser = Dsuser.objects.get(user_id=user_id)
            except Dsuser.DoesNotExist:
                self.add_error('user_id', '아이디 오류.')
                return
            
            if not check_password(password, dsuser.password):
                self.add_error('password', '비밀번호를 틀렸습니다.')
            else:
                self.user_id = dsuser.user_id