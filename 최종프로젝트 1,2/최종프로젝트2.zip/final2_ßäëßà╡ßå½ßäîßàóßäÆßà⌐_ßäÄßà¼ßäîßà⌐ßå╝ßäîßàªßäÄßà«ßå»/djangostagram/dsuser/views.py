
#비밀번호 검증을 위한 import
from django.contrib.auth.hashers import make_password
#forms에 form 작성하여 불러옴
from .forms import RegisterForm, LoginForm

from django.shortcuts import render, redirect
from django.views.generic.edit import FormView


def main(request):
    return render(request, 'index.html',{'user_id' : request.session.get('user')})

class LoginView(FormView):
    template_name = 'login.html'
    form_class = LoginForm
    success_url = '/'

    def form_valid(self, form):
        self.request.session['user'] = form.user_id
        return super().form_valid(form)

def logout(request):
    if request.session.get('user'):
        del(request.session['user'])
    return redirect('/')

class RegisterView(FormView):
    template_name = 'register.html'
    form_class = RegisterForm
    success_url = '/'