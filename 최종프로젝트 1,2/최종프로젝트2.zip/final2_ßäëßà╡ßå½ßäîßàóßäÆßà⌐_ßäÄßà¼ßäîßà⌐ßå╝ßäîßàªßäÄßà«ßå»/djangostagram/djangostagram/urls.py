from django.contrib import admin
from django.urls import path, include

from post.views import Post_card_List, post_upload

urlpatterns = [

    path('admin/', admin.site.urls),
    
    path('', Post_card_List.as_view()),

    #user url 연결
    path('user/', include('dsuser.urls')),
    
    #post url 연결
    path('post/', include('post.urls')),

    #upload url
    path('upload/', post_upload),
]


