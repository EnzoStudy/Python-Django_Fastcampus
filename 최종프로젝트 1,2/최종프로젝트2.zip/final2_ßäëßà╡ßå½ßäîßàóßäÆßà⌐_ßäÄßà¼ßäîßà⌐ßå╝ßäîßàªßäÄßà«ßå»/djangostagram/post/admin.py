from django.contrib import admin
from django.contrib.admin.options import ModelAdmin
from .models import Tag, Post


# tag 관리화면
class TagAdmin(admin.ModelAdmin):
    list_display = ('name',) 

admin.site.register(Tag, TagAdmin)


# 포스트 관리화면
class PostAdmin(admin.ModelAdmin):
    list_display = ('post_user', 'post_text') 

admin.site.register(Post, PostAdmin)