from django.shortcuts import render, redirect, get_object_or_404
from django.http import Http404
from django.core.paginator import Paginator
from django.views.generic import ListView
from .models import Post, Tag
from .forms import PostForm

from dsuser.models import Dsuser


# 게시글이 없는 경우 예외처리
def post_detail(request, pk):
    try:
        post = Post.objects.get(pk=pk)
    except Post.DoesNotExist:
        raise Http404('게시글이 없습니다.')
        

    page_number = request.session.get('page_number')
    return render(request, 'post_detail.html', {'post': post,
                                                'page_number': page_number})

def post_upload(request):
    #로그인 안했을때 로그인 페이지로 이동
    if not request.session.get('user'):
        return redirect('/user/login')

    #입력 되었을때 동작
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            user_id = request.session.get('user')
            #Post객체 생성
            post = Post()
            #제목
            post.post_title = form.cleaned_data['post_title']
            #내용
            post.post_text = form.cleaned_data['post_text']
            #작성자
            dsuser = Dsuser.objects.get(user_id=user_id)
            post.post_user = dsuser
            #이미지주소
            post.post_img_address = form.cleaned_data['post_img_address']
            #태그
            tags = [i.replace(' ', '') for i in filter(None, form.cleaned_data['post_tags'].split(','))]
            
            #객체저장
            post.save()

            #태그 DB에 신규 태그 저장
            for tag in tags:
                if not tag:
                    continue
                _tag, _ = Tag.objects.get_or_create(name=tag)
                print(_tag)
                post.post_tags.add(_tag)

            #원래 페이지로 리다이렉스
            return redirect('/post/')
    else:
        form = PostForm()

    return render(request, 'post_upload.html', {'form': form})



class Post_timeline_List(ListView):
    #post 타임라인 리스트 
    model = Post
    template_name = 'post timeline.html'
    context_object_name = 'post_timeline_list'

    #페이지네이션 설정
    paginate_by = 4
    #정렬 설정
    ordering = ['-post_date']


class Post_card_List(ListView):
    #post card 리스트
    model = Post
    template_name = 'post.html'
    context_object_name = 'post'

    #페이지네이션 설정
    paginate_by = 4
    #정렬 설정
    ordering = ['-post_date']
