from django import forms

class PostForm(forms.Form):

    post_title = forms.CharField(
        error_messages={ 'required': '제목 입력하시오.'}, 
        max_length=128, label="제목")

    post_img_address = forms.URLField(
        error_messages={ 'required': '이미지 입력하시오'}, 
        label="이미지 주소")

    post_text = forms.CharField(
        error_messages={ 'required': '내용 입력하시오.'}, 
        widget=forms.Textarea, label="내용")

    post_tags = forms.CharField(required=False, label="태그")