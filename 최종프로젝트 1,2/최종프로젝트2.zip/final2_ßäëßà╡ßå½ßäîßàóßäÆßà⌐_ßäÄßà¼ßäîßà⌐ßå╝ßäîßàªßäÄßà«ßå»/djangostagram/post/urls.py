from django.urls import path
from . import views

app_name = 'post'

urlpatterns = [

    # post 카드형태 페이지
    path('', views.Post_card_List.as_view(), name='post'),
    
    # 타임라인 형태의 페이지
    path('timeline/', views.Post_timeline_List.as_view(), name='post-timeline'),

    # 세부 정보 페이지
    path('detail/<int:pk>/', views.post_detail, name='post-detail'),
    path('<int:pk>/', views.post_detail, name='post-detail'),

    # 업로드 페이지
    path('upload/', views.post_upload, name='post-upload'),

]
